import {test} from '@playwright/test';

test('Launch Browser and Open Application', async({page})=>{

	await page.goto('https://www.techlearn.in');

})

test('Navigation Methods', async ({ page }) => {
    await page.goto('https://www.google.com');
    await page.goto('https://www.techlearn.in');
    await page.waitForTimeout(2000);
    await page.goBack();
    await page.waitForTimeout(2000);
    await page.goForward();
    await page.waitForTimeout(2000);
    await page.reload;

})

test('Clear Existing Data', async ({ page }) => {
    await page.goto('https://www.google.com');
    
    await page.locator('input[name="q"]').fill('Playwright');
    await page.waitForTimeout(2000);
    await page.locator('input[name="q"]').fill('Selenium');

})

