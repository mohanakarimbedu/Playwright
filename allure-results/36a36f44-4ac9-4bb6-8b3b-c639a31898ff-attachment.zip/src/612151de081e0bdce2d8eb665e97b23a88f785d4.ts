import {test} from '@playwright/test';

test('Launch Browser and Open Application', async({page})=>{

	await page.goto('https://www.techlearn.in');

})

test('Navigation Methods', async ({ page }) => {
    await page.goto('https://www.google.com');
    await page.goto('https://www.techlearn.in');
  
    await page.goBack();
 
    await page.goForward();
   
    await page.reload;

})

test('Clear Existing Data', async ({ page }) => {
    await page.goto('https://www.bharatdigitalnews.com/wp-login.php');

    await page.getByRole('textbox', { name: 'Username or Email Address' }).fill('Playwright');
    await page.waitForTimeout(2000);
    await page.getByRole('textbox', { name: 'Username or Email Address' }).clear();
    await page.waitForTimeout(2000);
    await page.getByRole('textbox', { name: 'Username or Email Address' }).fill('selenium');
     
    // No need to clear method use unlike Selenium
})

test('Fill and  Click Differnt Way to wright', async ({ page }) => {
    await page.goto('https://www.bharatdigitalnews.com/wp-login.php');

    await page.fill("#user_login", "Techlearn");
    
    await page.fill("input[name='pwd']", "Test@321");

    await page.check('#rememberme');

  //await page.click(getByRole('link', { name: 'Lost your password?' })); // Won't Work
    
    await page.getByRole('link', { name: 'Lost your password?' }).click();
     
})

test('Select Drop Down Options', async ({ page }) => {
    await page.goto('https://www.redmine.org/account/register');

    //  await page.locator('#user_language').selectOption('Japanese (日本語)');
    //   await page.locator("#user_language").selectOption({ index: 7 });
    
    await page.locator('#user_language').selectOption({ value: 'he' });

    await page.waitForTimeout(3000);
})
