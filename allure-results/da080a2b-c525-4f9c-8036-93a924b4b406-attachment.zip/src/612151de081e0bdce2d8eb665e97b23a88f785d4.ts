import {test,expect} from '@playwright/test';

test('Launch Browser', async({page})=>{

	await page.goto('https://www.techlearn.in');

})