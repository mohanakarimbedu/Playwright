import {test} from '@playwright/test';

test('Launch Browser and Open Application', async({page})=>{

	await page.goto('https://www.techlearn.in');

})

test('Navigation Methods', async ({ page }) => {
    await page.goto('https://www.google.com');
    await page.goto('https://www.techlearn.in');
    await page.waitForTimeout(2000);
    await page.goBack();
    await page.waitForTimeout(2000);
    await page.goForward();
    await page.waitForTimeout(2000);
    await page.reload;

})

test('Clear Existing Data', async ({ page }) => {
    await page.goto('https://www.bharatdigitalnews.com/wp-login.php');

    await page.getByRole('textbox', { name: 'Username or Email Address' }).fill('Playwright');
    await page.waitForTimeout(2000);
    await page.getByRole('textbox', { name: 'Username or Email Address' }).clear();
    await page.waitForTimeout(2000);
    await page.getByRole('textbox', { name: 'Username or Email Address' }).fill('selenium');
     
})

test('Fill and  Click Differnt Way', async ({ page }) => {
    await page.goto('https://www.bharatdigitalnews.com/wp-login.php');

    await page.fill("#user_login", "Techlearn");
    
    await page.fill("input[name='pwd']", "Test@321");
    
     
})

