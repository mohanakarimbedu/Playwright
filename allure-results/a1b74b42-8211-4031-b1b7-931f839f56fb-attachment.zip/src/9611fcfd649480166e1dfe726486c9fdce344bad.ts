import { test } from '@playwright/test';

test('Launch Browser', async ({ page }) => {
    await page.goto('https://www.techlearn.in')
})

test('navigation methods', async ({ page }) => {
    await page.goto('https://www.techlearn.in')
    await page.goto('https://www.playwright.dev')
    await page.goBack()
    await page.goForward()
    await page.reload()
})