import {test,expect} from '@playwright/test';

test.skip('Launch Browser and Open Application', async({page})=>{

	await page.goto('https://www.techlearn.in');

})

test('Navigation Methods', async ({ page }) => {
    await page.goto('https://www.google.com');
    await page.goto('https://www.techlearn.in');
    await page.waitForTimeout(2000);
    await page.goBack();
    await page.waitForTimeout(2000);
    await page.goForward();
    await page.waitForTimeout(2000);
    await page.reload;

})